-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 20, 2012 at 11:44 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mycms`
--
CREATE DATABASE `mycms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mycms`;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `Title` varchar(60) NOT NULL,
  `Content` text NOT NULL,
  `Date` date NOT NULL,
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `url` varchar(60) DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`Title`, `Content`, `Date`, `ID`, `url`, `time`) VALUES
('A working article', 'This article should fully accept and include html tags. I used nl2br , which apparently changes new lines in a text box to a break. awesome. well thats about the limit of my blog editing functionality at this point. will have to continue adding slowly.', '2012-09-19', 39, NULL, NULL),
('Next article', 'What happens when we insert two articles into my psycho blog.', '2012-09-19', 42, NULL, NULL),
('Sidebar regions', 'Have added sidebar regions to the CMS, the editor will have to work in such a fashion that the input comes out in "li" that way it will be easiest unless I do it with multiple blocks for more flexibility, also need to add header regions.', '2020-09-12', 43, NULL, NULL),
('dynamic urls', '<br />\r\nadded functionality where the posts automatically add a dynamic URL on the front page, it uses the PHP get method and sends the data to single.php ', '0000-00-00', 55, NULL, NULL),
('dynamic urls', '<br />\r\nadded functionality where the posts automatically add a dynamic URL on the front page, it uses the PHP get method and sends the data to single.php ', '2012-09-20', 56, NULL, '12:43:00'),
('Set up time stamp', 'added an auto time stamp, this will make it easier to track things. Starting to think it would be cool to make a more goal type system.', '2012-09-20', 57, NULL, '06:56:10'),
('Set up beijing time zone', 'Set up the time zone to china/ shanghai so that my times will be accurate instead of server time', '2012-09-20', 58, NULL, '12:59:08'),
('Internet setup at home', 'Finally have the internet setup at home. Will have to figure out a way to find the space to work at home without distractions.', '2012-09-20', 59, NULL, '15:50:03');

-- --------------------------------------------------------

--
-- Table structure for table `leftmenus`
--

CREATE TABLE IF NOT EXISTS `leftmenus` (
  `Title` varchar(60) NOT NULL,
  `Url` text NOT NULL,
  `Id` int(6) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `leftmenus`
--

INSERT INTO `leftmenus` (`Title`, `Url`, `Id`) VALUES
('chinasmack', 'http://www.chinasmack.com', 2),
('smashing magazine', 'http://www.smashingmagazine.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `Title` varchar(60) NOT NULL,
  `Url` text NOT NULL,
  `Id` int(6) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`Title`, `Url`, `Id`) VALUES
('google', 'http://www.google.com', 1),
('baidu', 'http://www.baidu.com', 2),
('china smack', 'http://www.chinasmack.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `rightmenus`
--

CREATE TABLE IF NOT EXISTS `rightmenus` (
  `Title` varchar(60) NOT NULL,
  `Url` text NOT NULL,
  `Id` int(6) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `rightmenus`
--

INSERT INTO `rightmenus` (`Title`, `Url`, `Id`) VALUES
('baidu', 'http://www.baidu.com', 1),
('smashing magazine', 'http://www.smashingmagazine.com/', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
